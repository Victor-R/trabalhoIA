package rescuecore2.scenario;




/**
 * Abstract Scenario interface
 * 
 * @author Salim
 * 
 */
public interface Scenario {

}
