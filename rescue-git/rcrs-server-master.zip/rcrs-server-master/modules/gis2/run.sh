java -ea -jar dist/Simulator.jar

